// Type definitions for big-integer (modernized)
// Project: https://github.com/peterolson/BigInteger.js

declare module "big-integer" {
    /**
     * Represents any input that can be converted into a BigInteger.
     */
    export type BigNumber = number | bigint | string | BigInteger;

    /**
     * Arbitrary-precision integer type.
     *
     * Instances are immutable: all operations return new BigInteger values.
     */
    export interface BigInteger {
        /**
         * Returns the absolute value of this number.
         */
        abs(): BigInteger;

        /**
         * Adds the given number to this one.
         *
         * @example
         * bigInt(10).add(5); // → 15
         */
        add(n: BigNumber): BigInteger;
        plus(n: BigNumber): BigInteger;

        /**
         * Subtracts the given number from this one.
         *
         * @example
         * bigInt(10).subtract(3); // → 7
         */
        subtract(n: BigNumber): BigInteger;
        minus(n: BigNumber): BigInteger;

        /**
         * Multiplies this number by the given one.
         *
         * @example
         * bigInt(6).multiply(7); // → 42
         */
        multiply(n: BigNumber): BigInteger;
        times(n: BigNumber): BigInteger;

        /**
         * Performs integer division, discarding the remainder.
         *
         * @example
         * bigInt(7).divide(3); // → 2
         */
        divide(n: BigNumber): BigInteger;
        over(n: BigNumber): BigInteger;

        /**
         * Returns the quotient and remainder of this / n.
         *
         * The sign of the remainder matches the sign of the dividend.
         */
        divmod(n: BigNumber): { quotient: BigInteger; remainder: BigInteger };

        /**
         * Returns the remainder of this / n.
         *
         * @example
         * bigInt(7).mod(3); // → 1
         */
        mod(n: BigNumber): BigInteger;
        remainder(n: BigNumber): BigInteger;

        /**
         * Raises this number to the given exponent.
         *
         * If the exponent is negative, returns 0.
         * bigInt.zero.pow(0) returns 1.
         */
        pow(exp: BigNumber): BigInteger;

        /**
         * Computes this^exp modulo mod.
         */
        modPow(exp: BigNumber, mod: BigNumber): BigInteger;

        /**
         * Computes the multiplicative inverse of this modulo n.
         *
         * @throws If the inverse does not exist.
         */
        modInv(n: BigNumber): BigInteger;

        /**
         * Squares this number.
         */
        square(): BigInteger;

        /**
         * Returns the next integer (this + 1).
         */
        next(): BigInteger;

        /**
         * Returns the previous integer (this - 1).
         */
        prev(): BigInteger;

        /**
         * Reverses the sign of this number.
         */
        negate(): BigInteger;

        /**
         * Bitwise AND with the given number.
         */
        and(n: BigNumber): BigInteger;

        /**
         * Bitwise OR with the given number.
         */
        or(n: BigNumber): BigInteger;

        /**
         * Bitwise XOR with the given number.
         */
        xor(n: BigNumber): BigInteger;

        /**
         * Bitwise NOT of this number.
         */
        not(): BigInteger;

        /**
         * Shifts this number left by n bits.
         * Negative n shifts right.
         *
         * @throws If n is outside [-9007199254740992, 9007199254740992].
         */
        shiftLeft(n: BigNumber): BigInteger;

        /**
         * Shifts this number right by n bits.
         * Negative n shifts left.
         *
         * @throws If n is outside [-9007199254740992, 9007199254740992].
         */
        shiftRight(n: BigNumber): BigInteger;

        /**
         * Compares this number to n.
         *
         * @returns 0 if equal, 1 if this > n, -1 if this < n.
         */
        compare(n: BigNumber): number;
        compareTo(n: BigNumber): number;
        compareAbs(n: BigNumber): number;

        /**
         * Equality and inequality checks.
         */
        equals(n: BigNumber): boolean;
        eq(n: BigNumber): boolean;
        notEquals(n: BigNumber): boolean;
        neq(n: BigNumber): boolean;

        /**
         * Relational comparisons.
         */
        greater(n: BigNumber): boolean;
        greaterOrEquals(n: BigNumber): boolean;
        lesser(n: BigNumber): boolean;
        lesserOrEquals(n: BigNumber): boolean;

        gt(n: BigNumber): boolean;
        geq(n: BigNumber): boolean;
        lt(n: BigNumber): boolean;
        leq(n: BigNumber): boolean;

        /**
         * Returns true if this is divisible by n.
         */
        isDivisibleBy(n: BigNumber): boolean;

        /**
         * Returns true if this is even.
         */
        isEven(): boolean;

        /**
         * Returns true if this is odd.
         */
        isOdd(): boolean;

        /**
         * Returns true if this is negative.
         *
         * Returns false for 0 and true for -0.
         */
        isNegative(): boolean;

        /**
         * Returns true if this is positive.
         *
         * Returns true for 0 and false for -0.
         */
        isPositive(): boolean;

        /**
         * Returns true if this is 0 or -0.
         */
        isZero(): boolean;

        /**
         * Returns true if this is 1 or -1.
         */
        isUnit(): boolean;

        /**
         * Returns true if this is prime.
         *
         * @param strict If true, uses a slower but deterministic test.
         */
        isPrime(strict?: boolean): boolean;

        /**
         * Returns true if this is very likely prime.
         *
         * @param iterations Number of rounds for the probabilistic test.
         */
        isProbablePrime(iterations?: number, rng?: () => number): boolean;

        /**
         * Returns the number of bits required to represent this in binary.
         */
        bitLength(): BigInteger;

        /**
         * Converts this number into an array of digits in the given radix.
         */
        toArray(radix: number): BaseArray;

        /**
         * Converts this number to a native JavaScript number.
         *
         * Precision is lost outside the safe integer range.
         */
        toJSNumber(): number;

        /**
         * Converts this number to a string in the given radix.
         */
        toString(radix?: number, alphabet?: string): string;

        /**
         * JSON serialization. Called by JSON.stringify.
         */
        toJSON(): string;

        /**
         * Implicit conversion to number (e.g. with + or arithmetic operators).
         *
         * Precision is lost outside the safe integer range.
         */
        valueOf(): number;
    }

    /**
     * Result of converting a BigInteger to an array representation.
     */
    export interface BaseArray {
        value: number[];
        isNegative: boolean;
    }

    /**
     * Static API for constructing and working with BigInteger values.
     *
     * The main export is also callable as a function: bigInt(...)
     */
    export interface BigIntegerStatic {
        /**
         * Equivalent to bigInt(0).
         */
        (): BigInteger;

        /**
         * Parses a JavaScript number into a BigInteger.
         */
        (n: number): BigInteger;

        /**
         * Parses a native bigint into a BigInteger.
         */
        (n: bigint): BigInteger;

        /**
         * Parses a string into a BigInteger.
         *
         * @param str The string representation.
         * @param base The numeric base (default 10).
         * @param alphabet Custom digit alphabet.
         * @param caseSensitive Whether alphabet is case-sensitive (default false).
         */
        (str: string, base?: BigNumber, alphabet?: string, caseSensitive?: boolean): BigInteger;

        /**
         * No-op: returns the given BigInteger.
         */
        (n: BigInteger): BigInteger;

        /**
         * Constructs a BigInteger from an array of digits in the given base.
         *
         * @param digits Array of digits.
         * @param base Base of the digits (default 10).
         * @param isNegative Whether the resulting number is negative.
         */
        fromArray(digits: BigNumber[], base?: BigNumber, isNegative?: boolean): BigInteger;

        /**
         * Greatest common divisor of a and b.
         */
        gcd(a: BigNumber, b: BigNumber): BigInteger;

        /**
         * Least common multiple of a and b.
         */
        lcm(a: BigNumber, b: BigNumber): BigInteger;

        /**
         * Returns the larger of a and b.
         */
        max(a: BigNumber, b: BigNumber): BigInteger;

        /**
         * Returns the smaller of a and b.
         */
        min(a: BigNumber, b: BigNumber): BigInteger;

        /**
         * Returns true if x is a BigInteger instance.
         */
        isInstance(x: unknown): x is BigInteger;

        /**
         * Returns a random integer between min and max (inclusive).
         *
         * @param rng Optional RNG returning a float in [0, 1).
         */
        randBetween(min: BigNumber, max: BigNumber, rng?: () => number): BigInteger;

        /**
         * Constant 0.
         */
        zero: BigInteger;

        /**
         * Constant 1.
         */
        one: BigInteger;

        /**
         * Constant -1.
         */
        minusOne: BigInteger;

        /**
         * Optional precomputed small integer constants, accessible by string key.
         *
         * Example: bigInt["5"], bigInt["-10"]
         */
        [key: string]: BigInteger | any;
    }

    /**
     * Main factory function for creating BigInteger instances.
     */
    const bigInt: BigIntegerStatic;

    export default bigInt;
}
