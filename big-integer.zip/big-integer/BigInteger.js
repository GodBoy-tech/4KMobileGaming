// src/BigInteger.ts
export type BigNumber = number | bigint | string | BigInteger;

function toBigInt(value: BigNumber): bigint {
    if (value instanceof BigInteger) return value.value;
    if (typeof value === "bigint") return value;
    if (typeof value === "number") return BigInt(value);
    if (typeof value === "string") return BigInt(value); // base-10 only here
    throw new TypeError("Unsupported BigNumber input");
}

export class BigInteger {
    readonly value: bigint;

    constructor(value: BigNumber = 0) {
        this.value = toBigInt(value);
    }

    // ---------- arithmetic ----------

    add(n: BigNumber): BigInteger {
        return new BigInteger(this.value + toBigInt(n));
    }

    subtract(n: BigNumber): BigInteger {
        return new BigInteger(this.value - toBigInt(n));
    }

    multiply(n: BigNumber): BigInteger {
        return new BigInteger(this.value * toBigInt(n));
    }

    divide(n: BigNumber): BigInteger {
        const d = toBigInt(n);
        if (d === 0n) throw new Error("Division by zero");
        return new BigInteger(this.value / d);
    }

    mod(n: BigNumber): BigInteger {
        const d = toBigInt(n);
        if (d === 0n) throw new Error("Modulo by zero");
        const r = this.value % d;
        // match mathematical mod (non-negative)
        return new BigInteger(r >= 0n ? r : r + d);
    }

    divmod(n: BigNumber): { quotient: BigInteger; remainder: BigInteger } {
        const d = toBigInt(n);
        if (d === 0n) throw new Error("Division by zero");
        const q = this.value / d;
        let r = this.value % d;
        if (r < 0n) r += d;
        return { quotient: new BigInteger(q), remainder: new BigInteger(r) };
    }

    pow(exp: BigNumber): BigInteger {
        const e = toBigInt(exp);
        if (e < 0n) {
            // integer pow with negative exponent → 0 by old semantics
            return new BigInteger(0n);
        }
        return new BigInteger(this.value ** e);
    }

    modPow(exp: BigNumber, mod: BigNumber): BigInteger {
        let e = toBigInt(exp);
        const m = toBigInt(mod);
        if (m === 0n) throw new Error("modPow with modulus 0");
        if (e < 0n) throw new Error("Negative exponent not supported in modPow");

        let base = this.mod(m).value;
        let result = 1n;

        while (e > 0n) {
            if (e & 1n) {
                result = (result * base) % m;
            }
            e >>= 1n;
            base = (base * base) % m;
        }

        return new BigInteger(result);
    }

    // ---------- comparisons ----------

    compare(n: BigNumber): number {
        const b = toBigInt(n);
        if (this.value === b) return 0;
        return this.value > b ? 1 : -1;
    }

    equals(n: BigNumber): boolean {
        return this.compare(n) === 0;
    }

    greater(n: BigNumber): boolean {
        return this.compare(n) > 0;
    }

    greaterOrEquals(n: BigNumber): boolean {
        return this.compare(n) >= 0;
    }

    lesser(n: BigNumber): boolean {
        return this.compare(n) < 0;
    }

    lesserOrEquals(n: BigNumber): boolean {
        return this.compare(n) <= 0;
    }

    // ---------- predicates ----------

    isZero(): boolean {
        return this.value === 0n;
    }

    isNegative(): boolean {
        return this.value < 0n;
    }

    isPositive(): boolean {
        return this.value > 0n;
    }

    isEven(): boolean {
        return (this.value & 1n) === 0n;
    }

    isOdd(): boolean {
        return (this.value & 1n) === 1n;
    }

    // ---------- bitwise ----------

    and(n: BigNumber): BigInteger {
        return new BigInteger(this.value & toBigInt(n));
    }

    or(n: BigNumber): BigInteger {
        return new BigInteger(this.value | toBigInt(n));
    }

    xor(n: BigNumber): BigInteger {
        return new BigInteger(this.value ^ toBigInt(n));
    }

    not(): BigInteger {
        return new BigInteger(~this.value);
    }

    shiftLeft(bits: BigNumber): BigInteger {
        return new BigInteger(this.value << toBigInt(bits));
    }

    shiftRight(bits: BigNumber): BigInteger {
        return new BigInteger(this.value >> toBigInt(bits));
    }

    // ---------- conversions ----------

    toString(radix: number = 10): string {
        return this.value.toString(radix);
    }

    toJSNumber(): number {
        return Number(this.value);
    }

    toJSON(): string {
        return this.toString(10);
    }

    valueOf(): number {
        return this.toJSNumber();
    }
}
