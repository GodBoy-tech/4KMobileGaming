#!/bin/bash

# Start the server in the background and record its PID
/path/to/your/server &  
SERVER_PID=$!

# Launch Xbox Cloud Gaming in Edge
microsoft-edge "https://www.xbox.com/play" &  
EDGE_PID=$!

# Wait for Edge to close
while kill -0 $EDGE_PID 2> /dev/null; do
    sleep 5
done

# Once Edge is closed, kill the server
kill $SERVER_PID
