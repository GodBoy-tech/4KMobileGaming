#!/bin/bash

PORT=8000
DX_SRC="../src_dx12/main_dx12.cpp"
DX_OUT="../build/game_dx12"
DIR="../dist"
FSR_DEFINE="-DENABLE_FSR3"
CXX_FLAGS="-std=c++17 -O2"

mkdir -p ../build

if command -v cl >/dev/null 2>&1; then
  echo "🔨 Compiling with MSVC..."
  cl "$DX_SRC" /Fe:"$DX_OUT.exe" /std:c++17 $FSR_DEFINE /O2 /link d3d12.lib dxgi.lib d3dcompiler.lib
elif [[ -n "$ANDROID_NDK_HOME" ]]; then
  echo "🛠️ MSVC not found. Compiling with NDK clang..."
  CLANG="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-aarch64/bin/clang++"
  if [ ! -f "$CLANG" ]; then
    echo "❌ NDK clang++ not found at: $CLANG"
  else
    "$CLANG" $CXX_FLAGS -o "$DX_OUT-ndk" "$DX_SRC" -D ENABLE_FSR3
  fi
else
  echo "⚠️ No compiler found. Skipping DX12 build."
fi

pkill -f "python3 -m http.server" 2>/dev/null
cd "$DIR"
python3 -m http.server $PORT &

sleep 2
URL="http://localhost:$PORT"
OS=$(uname)

termux-open-url http://localhost:8000

echo "🌐 Launching Edge at: $URL"
if [[ "$OS" == "Darwin" ]]; then
  open -a "Microsoft Edge" --args --start-fullscreen "$URL"
elif [[ "$OS" == "Linux" ]]; then
  microsoft-edge-stable --kiosk "$URL" &
elif [[ "$OS" == MINGW* || "$OS" == MSYS* || "$OS" == CYGWIN* ]]; then
  start msedge --start-fullscreen "$URL"
else
  echo "❌ Edge auto-launch not supported on this OS."
fi
cat <<EOF > ../src_web/main.js
console.log("🚀 WebGPU environment starting...");

window.addEventListener("gamepadconnected", (e) => {
  console.log("🎮 Gamepad detected:", e.gamepad.id);
});
EOF
USERNAME="Josh"
ENV_MODE="dev"

cat <<EOF > ../src_web/main.js
const config = {
  username: "$USERNAME",
  environment: "$ENV_MODE"
};

console.log("🔧 Config loaded:", config);
EOF
echo "✅ Project launched."
