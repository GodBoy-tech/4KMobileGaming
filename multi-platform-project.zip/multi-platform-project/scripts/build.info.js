// scripts/build-info.js
const fs = require('fs')
const pkg = require('../package.json')

const info = {
  name: pkg.name,
  version: pkg.version,
  author: pkg.author,
  license: pkg.license,
  builtAt: new Date().toISOString()
}

fs.writeFileSync('./public/build-info.json', JSON.stringify(info, null, 2))
console.log('✅ build-info.json generated')
