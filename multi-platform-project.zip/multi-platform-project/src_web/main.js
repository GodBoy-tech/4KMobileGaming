const config = {
  username: "Josh",
  environment: "dev"
};

console.log("🔧 Config loaded:", config);
