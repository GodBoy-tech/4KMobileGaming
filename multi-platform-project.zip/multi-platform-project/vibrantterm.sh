echo -e "\e[1;36m[3/7] Refreshing www/ folder...\e[0m"
