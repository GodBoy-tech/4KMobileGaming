# 🧱 WebGLBuilder

A sleek, high-performance **multi-platform WebGL PWA** builder.  
Built with React + Vite + Capacitor + a whole lot of shell magic 🛠️✨

![WebGLBuilder Icon](./dist/assets/icons/icon-512.png)

---

## 🚀 Features

- 🖥️ Frontend: React + Vite
- 📦 Native Android build: Capacitor + Gradle
- 🎨 PWA: Offline-ready with `manifest.webmanifest`
- 📂 Fully scriptable deploy pipeline (`full-deploy`)
- 🔧 Auto-resized icons from high-res JPEG → `icon-192.png`, `icon-512.png`
- 📲 Instant APK builds via Termux on Android

---

## 📁 Project Structure

---

## 🛠️ Build & Deploy

> ⚡ One command to build, sync, package and install your APK:

```bash
~/.shortcuts/full-deploy
