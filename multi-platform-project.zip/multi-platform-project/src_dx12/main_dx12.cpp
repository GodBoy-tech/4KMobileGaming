# DX12 Entry Point with FSR3\n#include <windows.h>\n#include <d3d12.h>\nint WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {\n#ifdef ENABLE_FSR3\n  // TODO: FSR3 Init\n#endif\nreturn 0; }
