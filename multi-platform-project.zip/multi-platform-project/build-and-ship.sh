#!/data/data/com.termux/files/usr/bin/bash

#!/data/data/com.termux/files/usr/bin/bash

# 🧱 Path setup
PROJECT_DIR="$HOME/my-apk"
OUTPUT_DIR="/storage/emulated/0/WebGL"
TIMESTAMP=$(date +%Y%m%d-%H%M)
APK_NAME="MyProject-$TIMESTAMP.apk"
METADATA_NAME="${APK_NAME%.apk}.txt"

# ✅ Step 1: Ensure target directory exists
mkdir -p "$OUTPUT_DIR"

# 🧹 Clean up old builds (keep only latest 3 APKs + metadata)
MAX_BUILDS=3
find "$OUTPUT_DIR" -maxdepth 1 -type f \( -iname "*.apk" -o -iname "*.txt" \) \
  -printf "%T@ %p\n" | sort -n | head -n -$((MAX_BUILDS * 2)) | cut -d' ' -f2- | xargs -r rm -f

# 🔄 Step 2: Sync Capacitor project
cd "$PROJECT_DIR" || exit 1
npx cap sync || exit 1

# 🔨 Step 3: Build the APK
cd android || exit 1
chmod +x ./gradlew
./gradlew assembleDebug || exit 1

# 📦 Step 4: Copy built APK to output directory
cp ./app/build/outputs/apk/debug/app-debug.apk "$OUTPUT_DIR/$APK_NAME" || exit 1

# 📝 Step 5: Write metadata
{
  echo "📦 Build Info"
  echo "====================="
  echo "Filename:  $APK_NAME"
  echo "Date:      $(date '+%Y-%m-%d %H:%M:%S')"
  echo "Version:   1.0.${TIMESTAMP: -4}"
  echo "Built at:  $PROJECT_DIR/www/"
  echo
  echo "📝 Changelog:"
  echo "- Assets synced and APK built"
  echo "- Saved to: $OUTPUT_DIR"
  echo "- Launched system installer"
} > "$OUTPUT_DIR/$METADATA_NAME"

# 📲 Step 6: Launch Android installer
am start -a android.intent.action.VIEW \
  -d "file://$OUTPUT_DIR/$APK_NAME" \
  -t "application/vnd.android.package-archive" \
  --user 0

# ✅ Optional: Toast confirmation
termux-toast "✅ APK ready and installer launched!"
