<template>
  <footer class="footer">
    <p v-if="info.version">
      {{ info.name }} v{{ info.version }} · Built on {{ formatDate(info.builtAt) }}
    </p>
  </footer>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'

const info = ref({
  name: '',
  version: '',
  builtAt: ''
})

onMounted(async () => {
  const res = await fetch('/build-info.json')
  info.value = await res.json()
})

function formatDate(dateStr: string) {
  const d = new Date(dateStr)
  return d.toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}
</script>

<style scoped>
.footer {
  font-size: 0.8em;
  text-align: center;
  color: #999;
  margin: 2rem auto 0;
}
</style>
